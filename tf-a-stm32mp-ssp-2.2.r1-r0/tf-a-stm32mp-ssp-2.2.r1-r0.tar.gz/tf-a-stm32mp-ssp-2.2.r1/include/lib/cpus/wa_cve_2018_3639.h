/*
 * Copyright (c) 2018, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef WA_CVE_2018_3639_H
#define WA_CVE_2018_3639_H

void *wa_cve_2018_3639_get_disable_ptr(void);

#endif /* WA_CVE_2018_3639_H */
