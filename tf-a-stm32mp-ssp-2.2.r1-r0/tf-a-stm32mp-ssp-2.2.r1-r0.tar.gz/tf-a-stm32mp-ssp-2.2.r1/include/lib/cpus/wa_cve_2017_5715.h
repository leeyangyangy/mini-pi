/*
 * Copyright (c) 2018, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef WA_CVE_2017_5715_H
#define WA_CVE_2017_5715_H

int check_wa_cve_2017_5715(void);

#endif /* WA_CVE_2017_5715_H */
