/*
 * Copyright (c) 2018, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef BL2U_H
#define BL2U_H

void bl2u_main(void);

#endif /* BL2U_H */
