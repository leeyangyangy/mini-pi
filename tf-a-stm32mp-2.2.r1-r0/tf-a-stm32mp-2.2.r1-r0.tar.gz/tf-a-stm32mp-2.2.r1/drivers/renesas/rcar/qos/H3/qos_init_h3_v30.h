/*
 * Copyright (c) 2018, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_H3_V30_H
#define QOS_INIT_H3_V30_H

void qos_init_h3_v30(void);

#endif /* QOS_INIT_H3_V30_H */
