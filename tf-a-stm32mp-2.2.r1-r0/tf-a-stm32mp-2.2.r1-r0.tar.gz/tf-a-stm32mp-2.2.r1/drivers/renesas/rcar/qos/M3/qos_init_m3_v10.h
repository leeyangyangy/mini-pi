/*
 * Copyright (c) 2015-2017, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_M3_V10_H
#define QOS_INIT_M3_V10_H

void qos_init_m3_v10(void);

#endif /* QOS_INIT_M3_V10_H */
