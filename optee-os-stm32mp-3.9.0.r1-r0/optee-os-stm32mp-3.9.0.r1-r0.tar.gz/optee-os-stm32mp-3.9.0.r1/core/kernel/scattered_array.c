// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2018, Linaro Limited
 */

#include <scattered_array.h>

const void *scattered_array_relax_ptr(const void *p)
{
	return p;
}
